package util

case class Pixel(red: Integer, green: Integer, blue: Integer) {
}
